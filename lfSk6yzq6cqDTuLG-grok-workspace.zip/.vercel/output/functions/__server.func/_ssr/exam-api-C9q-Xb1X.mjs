import { r as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { a as getSession, i as getExam, o as nextPhase, t as EXAMS } from "./catalog-d6Irk40O.mjs";
import { r as getSql } from "./db-B9o2h089.mjs";
import { t as authMiddleware } from "./middleware-BUH4w92X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exam-api-C9q-Xb1X.js
function scaleScore(correct, total, max = 1e3) {
	if (total <= 0) return 0;
	return Math.round(correct / total * max);
}
function gradeMcq(question, answer) {
	const correct = answer === question.answer;
	return {
		correct,
		earned: correct ? 1 : 0,
		max: 1
	};
}
function gradeMulti(question, answer) {
	const map = isRecord$1(answer) ? answer : {};
	const perBlank = {};
	let earned = 0;
	for (const blank of question.blanks) {
		const ok = map[blank.id] === blank.answer;
		perBlank[blank.id] = ok;
		if (ok) earned += 1;
	}
	return {
		correct: earned === question.blanks.length,
		earned,
		max: question.blanks.length,
		perBlank
	};
}
function maxEssayPoints(question) {
	return question.parts.reduce((s, p) => s + p.maxPoints, 0);
}
function keywordScore(user, model, rubric, maxPoints) {
	const text = normalize(user);
	if (!text) return 0;
	const keys = extractKeys(`${model} ${rubric}`);
	if (keys.length === 0) return text.length >= 8 ? Math.round(maxPoints * .4) : 0;
	let hits = 0;
	for (const k of keys) if (text.includes(k)) hits += 1;
	const ratio = hits / keys.length;
	let score = Math.round(maxPoints * Math.min(1, ratio * 1.15));
	if (text.length < 6) score = Math.min(score, Math.ceil(maxPoints * .25));
	return Math.max(0, Math.min(maxPoints, score));
}
function phaseResult(phase, rawCorrect, rawTotal, maxScore, passScore) {
	const scaled = scaleScore(rawCorrect, rawTotal, maxScore);
	return {
		phase,
		rawCorrect,
		rawTotal,
		scaled,
		passed: scaled >= passScore
	};
}
function isRecord$1(v) {
	return typeof v === "object" && v !== null && !Array.isArray(v);
}
function normalize(s) {
	return s.replace(/\s+/g, "").toLowerCase();
}
function extractKeys(source) {
	const parts = source.split(/[\s、。．，；;：:・／/\n()（）「」『』【】\[\]{}<>]+/).map((p) => p.trim()).filter((p) => p.length >= 2 && !STOP.has(p));
	const uniq = [];
	for (const p of parts) if (!uniq.includes(p) && uniq.length < 12) uniq.push(p);
	return uniq;
}
var STOP = /* @__PURE__ */ new Set([
	"こと",
	"ため",
	"もの",
	"これ",
	"それ",
	"ある",
	"する",
	"なる",
	"いる",
	"れる",
	"られる",
	"ます",
	"です",
	"した",
	"して",
	"され",
	"よう",
	"など",
	"また",
	"および",
	"または",
	"について",
	"により",
	"による",
	"として",
	"において",
	"に対し",
	"から",
	"まで",
	"場合",
	"とき",
	"設問",
	"解答",
	"正解",
	"解説",
	"観点",
	"内容"
]);
function stripQuestion(q) {
	if (q.kind === "mcq") {
		const { answer: _a, explanation: _e, ...rest } = q;
		return rest;
	}
	if (q.kind === "multi") {
		const { explanation: _e, ...rest } = q;
		return {
			...rest,
			blanks: q.blanks.map(({ answer: _a, explanation: _x, ...b }) => b)
		};
	}
	return {
		...q,
		parts: q.parts.map(({ answer: _a, rubric: _r, explanation: _e, ...p }) => p)
	};
}
function stripMany(questions) {
	return questions.map(stripQuestion);
}
function parseJson(v, fallback) {
	if (v == null) return fallback;
	if (typeof v === "string") try {
		return JSON.parse(v);
	} catch {
		return fallback;
	}
	return v;
}
function mapAttempt(row) {
	return {
		id: row.id,
		userId: row.user_id,
		examKind: row.exam_kind,
		sessionKey: row.session_key,
		status: row.status,
		currentPhase: row.current_phase,
		startedAt: row.started_at,
		finishedAt: row.finished_at,
		phaseStartedAt: row.phase_started_at,
		questionIds: parseJson(row.question_ids, []),
		scoredIds: parseJson(row.scored_ids, []),
		selectedIds: parseJson(row.selected_ids, []),
		scores: parseJson(row.scores, []),
		passed: row.passed,
		createdAt: row.created_at,
		papers: parseJson(row.papers, {})
	};
}
async function loadAttempt(sql, id, userId) {
	const row = (await sql`
    select * from exam_attempts where id = ${id} and user_id = ${userId} limit 1
  `)[0];
	if (!row) throw new Error("受験記録が見つかりません");
	return mapAttempt(row);
}
async function loadAnswers(sql, attemptId, userId) {
	return sql`
    select question_id, phase, answer, flagged, is_correct, earned, max_points, ai_feedback
    from exam_answers where attempt_id = ${attemptId} and user_id = ${userId}
  `;
}
var startAttempt_createServerFn_handler = createServerRpc({
	id: "eef81d43a45b8c09c555b678538a23a292d55079df48be94296f73993cace8fe",
	name: "startAttempt",
	filename: "src/lib/exam-api.ts"
}, (opts) => startAttempt.__executeServer(opts));
var startAttempt = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(startAttempt_createServerFn_handler, async ({ context, data }) => {
	const exam = getExam(data.kind);
	const session = exam ? getSession(data.kind, data.sessionKey) : void 0;
	if (!exam || !session) throw new Error("試験区分または実施回が不正です");
	const { assemblePapers, questionsByIds } = await import("./assemble-agZjc1VV.mjs");
	const assembled = assemblePapers(data.kind, data.sessionKey, `${context.userId}:${Date.now()}`);
	const first = exam.phases[0];
	const qids = assembled.papers[first.key] ?? [];
	const scored = assembled.scored[first.key] ?? [];
	const id = crypto.randomUUID();
	const sql = await getSql();
	await sql`
      insert into exam_attempts (
        id, user_id, exam_kind, session_key, status, current_phase,
        question_ids, scored_ids, selected_ids, scores, papers
      ) values (
        ${id}, ${context.userId}, ${data.kind}, ${data.sessionKey}, 'in_progress', ${first.key},
        ${JSON.stringify(qids)}::jsonb, ${JSON.stringify(scored)}::jsonb,
        ${JSON.stringify([])}::jsonb, ${JSON.stringify([])}::jsonb,
        ${JSON.stringify(assembled.papers)}::jsonb
      )
    `;
	const questions = stripMany(questionsByIds(qids));
	return {
		attempt: await loadAttempt(sql, id, context.userId),
		questions
	};
});
var getAttempt_createServerFn_handler = createServerRpc({
	id: "9308d557fe45278f7a43e8db914be553bfc233c90f7d6e5b389a0b909ee7c4bf",
	name: "getAttempt",
	filename: "src/lib/exam-api.ts"
}, (opts) => getAttempt.__executeServer(opts));
var getAttempt = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((input) => input).handler(getAttempt_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const attempt = await loadAttempt(sql, data.attemptId, context.userId);
	const { questionsByIds } = await import("./assemble-agZjc1VV.mjs");
	const questions = stripMany(questionsByIds(attempt.questionIds));
	const answers = await loadAnswers(sql, attempt.id, context.userId);
	const exam = EXAMS[attempt.examKind];
	const phase = exam.phases.find((p) => p.key === attempt.currentPhase) ?? exam.phases[0];
	const phaseSelected = attempt.selectedIds.filter((id) => (attempt.papers[attempt.currentPhase] ?? []).includes(id));
	const needsSelect = Boolean(phase.selectable) && phaseSelected.length < (phase.selectable?.pick ?? 0);
	return {
		attempt,
		questions,
		answers: answers.map((a) => ({
			questionId: a.question_id,
			phase: a.phase,
			answer: parseJson(a.answer, null),
			flagged: a.flagged
		})),
		needsSelect,
		exam,
		phase,
		reveal: false
	};
});
var listAttempts_createServerFn_handler = createServerRpc({
	id: "e3ed6185dc795fa5d94d0ce81b3002db6afa7fc025f7ee315b758c26d19a8fa3",
	name: "listAttempts",
	filename: "src/lib/exam-api.ts"
}, (opts) => listAttempts.__executeServer(opts));
var listAttempts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listAttempts_createServerFn_handler, async ({ context }) => {
	return (await (await getSql())`
      select * from exam_attempts where user_id = ${context.userId}
      order by created_at desc limit 80
    `).map(mapAttempt);
});
var saveAnswer_createServerFn_handler = createServerRpc({
	id: "afb4e8baba4ddfd7bd796dacc7c7042c2344349d5eeeffec73a940fc6b9a3a43",
	name: "saveAnswer",
	filename: "src/lib/exam-api.ts"
}, (opts) => saveAnswer.__executeServer(opts));
var saveAnswer = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveAnswer_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const attempt = await loadAttempt(sql, data.attemptId, context.userId);
	if (attempt.status !== "in_progress") throw new Error("終了した試験は変更できません");
	if (!attempt.questionIds.includes(data.questionId)) throw new Error("この問題は受験対象外です");
	await sql`
      insert into exam_answers (attempt_id, user_id, question_id, phase, answer, flagged)
      values (
        ${attempt.id}, ${context.userId}, ${data.questionId}, ${attempt.currentPhase},
        ${JSON.stringify(data.answer)}::jsonb, ${data.flagged ?? false}
      )
      on conflict (attempt_id, question_id) do update set
        answer = excluded.answer,
        flagged = excluded.flagged,
        updated_at = now()
    `;
	return { ok: true };
});
var saveAnswers_createServerFn_handler = createServerRpc({
	id: "9194a0036b8cca0a33e29c0ab77f33f1ce6a8bb845002274bfbb8289eaeb410a",
	name: "saveAnswers",
	filename: "src/lib/exam-api.ts"
}, (opts) => saveAnswers.__executeServer(opts));
var saveAnswers = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveAnswers_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const attempt = await loadAttempt(sql, data.attemptId, context.userId);
	if (attempt.status !== "in_progress") throw new Error("終了した試験は変更できません");
	const allowed = new Set(attempt.questionIds);
	for (const item of data.items) {
		if (!allowed.has(item.questionId)) continue;
		await sql`
        insert into exam_answers (attempt_id, user_id, question_id, phase, answer, flagged)
        values (
          ${attempt.id}, ${context.userId}, ${item.questionId}, ${attempt.currentPhase},
          ${JSON.stringify(item.answer)}::jsonb, ${item.flagged ?? false}
        )
        on conflict (attempt_id, question_id) do update set
          answer = excluded.answer,
          flagged = excluded.flagged,
          updated_at = now()
      `;
	}
	return { ok: true };
});
var confirmSelection_createServerFn_handler = createServerRpc({
	id: "76a466ad46dd1333f9fe3cbb0326248d769387966f76c8b6830f77055e172ff7",
	name: "confirmSelection",
	filename: "src/lib/exam-api.ts"
}, (opts) => confirmSelection.__executeServer(opts));
var confirmSelection = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(confirmSelection_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const attempt = await loadAttempt(sql, data.attemptId, context.userId);
	const phase = EXAMS[attempt.examKind].phases.find((p) => p.key === attempt.currentPhase);
	if (!phase?.selectable) throw new Error("この科目に選択はありません");
	const candidates = attempt.papers[phase.key] ?? [];
	const selected = data.selectedIds.filter((id) => candidates.includes(id));
	const required = candidates.filter((id) => (phase.selectable?.requiredIds ?? []).some((r) => id.endsWith(`-${r}`) || id.endsWith(r)));
	for (const r of required) if (!selected.includes(r)) throw new Error("必須問題を含めてください");
	if (selected.length !== phase.selectable.pick) throw new Error(`${phase.selectable.pick}問を選択してください`);
	const selectedIds = [...attempt.selectedIds.filter((id) => !candidates.includes(id)), ...selected];
	const scoredAll = [...parseJson((await sql`select scored_ids from exam_attempts where id = ${attempt.id}`)[0]?.scored_ids, attempt.scoredIds).filter((id) => !candidates.includes(id)), ...selected];
	await sql`
      update exam_attempts set
        selected_ids = ${JSON.stringify(selectedIds)}::jsonb,
        question_ids = ${JSON.stringify(selected)}::jsonb,
        scored_ids = ${JSON.stringify(scoredAll)}::jsonb,
        phase_started_at = now()
      where id = ${attempt.id} and user_id = ${context.userId}
    `;
	const { questionsByIds } = await import("./assemble-agZjc1VV.mjs");
	return {
		questions: stripMany(questionsByIds(selected)),
		selectedIds
	};
});
var submitPhase_createServerFn_handler = createServerRpc({
	id: "066144f8c89943633def34b560091545dd61b8db2196c64ae70c7fe408cb4482",
	name: "submitPhase",
	filename: "src/lib/exam-api.ts"
}, (opts) => submitPhase.__executeServer(opts));
var submitPhase = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(submitPhase_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const attempt = await loadAttempt(sql, data.attemptId, context.userId);
	if (attempt.status !== "in_progress") throw new Error("既に終了しています");
	const phase = EXAMS[attempt.examKind].phases.find((p) => p.key === attempt.currentPhase);
	if (!phase) throw new Error("科目が見つかりません");
	const { questionsByIds } = await import("./assemble-agZjc1VV.mjs");
	const qs = questionsByIds(attempt.questionIds);
	const answerRows = await loadAnswers(sql, attempt.id, context.userId);
	const ansMap = new Map(answerRows.map((a) => [a.question_id, parseJson(a.answer, null)]));
	const score = await gradePhase(qs, ansMap, new Set(attempt.scoredIds.length ? attempt.scoredIds : attempt.questionIds), phase.maxScore, phase.passScore, phase.key);
	for (const q of qs) {
		const g = score.perQuestion[q.id];
		if (!g) continue;
		await sql`
        insert into exam_answers (attempt_id, user_id, question_id, phase, answer, is_correct, earned, max_points, ai_feedback)
        values (
          ${attempt.id}, ${context.userId}, ${q.id}, ${phase.key},
          ${JSON.stringify(ansMap.get(q.id) ?? null)}::jsonb,
          ${g.correct}, ${g.earned}, ${g.max}, ${g.feedback}
        )
        on conflict (attempt_id, question_id) do update set
          is_correct = excluded.is_correct,
          earned = excluded.earned,
          max_points = excluded.max_points,
          ai_feedback = excluded.ai_feedback,
          updated_at = now()
      `;
	}
	const scores = [...attempt.scores.filter((s) => s.phase !== phase.key), score.summary];
	const nxt = nextPhase(attempt.examKind, phase.key);
	if (!nxt) {
		const passed = scores.every((s) => s.passed);
		await sql`
        update exam_attempts set
          status = 'completed', finished_at = now(), scores = ${JSON.stringify(scores)}::jsonb,
          passed = ${passed}
        where id = ${attempt.id} and user_id = ${context.userId}
      `;
		return {
			done: true,
			nextPhase: null,
			scores,
			passed
		};
	}
	const nextIds = attempt.papers[nxt.key] ?? [];
	let scoredIds = attempt.scoredIds;
	if (!nxt.selectable) {
		const { hashString, pickN, seededRandom } = await import("./utils-Bm8F9AEr.mjs").then((n) => n.c);
		const rand = seededRandom(hashString(`${attempt.id}:${nxt.key}`));
		scoredIds = unique([...scoredIds, ...pickN(nextIds, nxt.scoredCount, rand)]);
	}
	await sql`
      update exam_attempts set
        current_phase = ${nxt.key},
        phase_started_at = now(),
        question_ids = ${JSON.stringify(nextIds)}::jsonb,
        scored_ids = ${JSON.stringify(scoredIds)}::jsonb,
        scores = ${JSON.stringify(scores)}::jsonb
      where id = ${attempt.id} and user_id = ${context.userId}
    `;
	return {
		done: false,
		nextPhase: nxt.key,
		scores,
		passed: null
	};
});
var getResult_createServerFn_handler = createServerRpc({
	id: "5294fbaed37f72ac09775cf10582d690c7f6e8050366ba244a7594f73a2e875e",
	name: "getResult",
	filename: "src/lib/exam-api.ts"
}, (opts) => getResult.__executeServer(opts));
var getResult = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((input) => input).handler(getResult_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const attempt = await loadAttempt(sql, data.attemptId, context.userId);
	if (attempt.status !== "completed") throw new Error("まだ採点結果を表示できません");
	const { questionsByIds } = await import("./assemble-agZjc1VV.mjs");
	const questions = questionsByIds(unique(Object.values(attempt.papers).flat()));
	const answers = await loadAnswers(sql, attempt.id, context.userId);
	return {
		attempt,
		exam: EXAMS[attempt.examKind],
		questions,
		answers: answers.map((a) => ({
			questionId: a.question_id,
			phase: a.phase,
			answer: parseJson(a.answer, null),
			flagged: a.flagged,
			isCorrect: a.is_correct,
			earned: a.earned,
			maxPoints: a.max_points,
			aiFeedback: a.ai_feedback
		}))
	};
});
function unique(ids) {
	return [...new Set(ids)];
}
async function gradePhase(qs, ansMap, scoredSet, maxScore, passScore, phaseKey) {
	const perQuestion = {};
	let rawCorrect = 0;
	let rawTotal = 0;
	const graded = await Promise.all(qs.map(async (q) => {
		const user = ansMap.get(q.id) ?? null;
		if (q.kind === "mcq") {
			const g = gradeMcq(q, user);
			return [q.id, {
				...g,
				feedback: null
			}];
		}
		if (q.kind === "multi") {
			const g = gradeMulti(q, user);
			return [q.id, {
				correct: g.correct,
				earned: g.earned,
				max: g.max,
				feedback: null
			}];
		}
		const g = await gradeEssayQuestion(q, user);
		return [q.id, g];
	}));
	for (const [id, g] of graded) {
		perQuestion[id] = g;
		if (scoredSet.has(id) && g.max > 0) {
			rawTotal += 1;
			rawCorrect += g.earned / g.max;
		}
	}
	return {
		summary: phaseResult(phaseKey, rawCorrect, rawTotal, maxScore, passScore),
		perQuestion
	};
}
async function gradeEssayQuestion(q, user) {
	const map = isRecord(user) ? user : {};
	const api = await tryAiGrade(q, map);
	if (api) return api;
	let earned = 0;
	let max = 0;
	const notes = [];
	for (const p of q.parts) {
		max += p.maxPoints;
		const ua = String(map[p.id] ?? "");
		if (p.type === "choice") {
			const correct = ua.trim() === p.answer.trim() || ua.trim().startsWith(p.answer.trim());
			const e = correct ? p.maxPoints : 0;
			earned += e;
			notes.push(`${p.label}: ${correct ? "正" : "誤"}`);
		} else {
			const e = keywordScore(ua, p.answer, p.rubric, p.maxPoints);
			earned += e;
			notes.push(`${p.label}: ${e}/${p.maxPoints}（自動採点）`);
		}
	}
	return {
		correct: earned >= max * .6,
		earned,
		max: max || maxEssayPoints(q),
		feedback: notes.join(" / ")
	};
}
async function tryAiGrade(q, map) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return null;
	const payload = q.parts.map((p) => ({
		id: p.id,
		label: p.label,
		prompt: p.prompt,
		modelAnswer: p.answer,
		rubric: p.rubric,
		maxPoints: p.maxPoints,
		user: String(map[p.id] ?? "")
	}));
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			signal: AbortSignal.timeout(12e3),
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				max_tokens: 900,
				temperature: 0,
				messages: [{
					role: "system",
					content: "あなたは情報処理技術者試験の採点官です。各設問について 0〜maxPoints の整数点と短い講評をJSONで返してください。形式: {\"parts\":[{\"id\":\"a1\",\"earned\":0,\"comment\":\"...\"}],\"summary\":\"...\"} のみ。"
				}, {
					role: "user",
					content: JSON.stringify({
						title: q.title,
						parts: payload
					})
				}]
			})
		});
		if (!res.ok) return null;
		const text = (await res.json()).choices[0]?.message.content ?? "";
		const jsonStart = text.indexOf("{");
		const jsonEnd = text.lastIndexOf("}");
		if (jsonStart < 0) return null;
		const parsed = JSON.parse(text.slice(jsonStart, jsonEnd + 1));
		let earned = 0;
		let max = 0;
		for (const p of q.parts) {
			max += p.maxPoints;
			const row = parsed.parts.find((x) => x.id === p.id);
			const e = Math.max(0, Math.min(p.maxPoints, Math.round(row?.earned ?? 0)));
			earned += e;
		}
		return {
			correct: earned >= max * .6,
			earned,
			max,
			feedback: parsed.summary ?? "AI採点"
		};
	} catch {
		return null;
	}
}
function isRecord(v) {
	return typeof v === "object" && v !== null && !Array.isArray(v);
}
//#endregion
export { confirmSelection_createServerFn_handler, getAttempt_createServerFn_handler, getResult_createServerFn_handler, listAttempts_createServerFn_handler, saveAnswer_createServerFn_handler, saveAnswers_createServerFn_handler, startAttempt_createServerFn_handler, submitPhase_createServerFn_handler };
