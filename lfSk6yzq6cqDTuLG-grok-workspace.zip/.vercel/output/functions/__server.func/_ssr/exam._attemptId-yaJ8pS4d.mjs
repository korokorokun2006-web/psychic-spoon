import { o as __toESM } from "../_runtime.mjs";
import { C as useNavigate, Q as require_react, T as require_jsx_runtime, _ as Outlet, m as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as formatDuration } from "./utils-Bm8F9AEr.mjs";
import { c as FlagOff, s as Flag } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Route$3 } from "./router-DlJC4z8l.mjs";
import { l as submitPhase, n as confirmSelection, o as saveAnswer, r as getAttempt, s as saveAnswers, t as AppShell } from "./exam-api-Cgv7AjeX.mjs";
import { r as FIELD_LABEL } from "./labels-TS9A5-VG.mjs";
import { t as CHOICE_KEYS } from "./types-DS8IYQ4-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exam._attemptId-yaJ8pS4d.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ExamTimer({ startedAt, durationMin, onExpire }) {
	const end = new Date(startedAt).getTime() + durationMin * 60 * 1e3;
	const [left, setLeft] = (0, import_react.useState)(() => Math.max(0, end - Date.now()));
	(0, import_react.useEffect)(() => {
		let fired = false;
		const tick = () => {
			const v = Math.max(0, end - Date.now());
			setLeft(v);
			if (v <= 0 && !fired) {
				fired = true;
				onExpire();
			}
		};
		tick();
		const t = window.setInterval(tick, 250);
		return () => window.clearInterval(t);
	}, [end, onExpire]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "tabular-nums rounded-md px-3 py-1.5 text-sm font-semibold " + (left <= 3e5 ? "bg-fail-bg text-fail" : left <= 6e5 ? "bg-warn-bg text-warn" : "bg-paper-2 text-ink"),
		"aria-live": "polite",
		children: ["残り ", formatDuration(left / 1e3)]
	});
}
function QuestionView({ question, index, total, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-xl border border-line bg-card p-5 shadow-card sm:p-7",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs font-medium tracking-wide text-muted",
			children: [
				"問",
				index + 1,
				" / ",
				total,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-2 text-line-strong",
					children: "/"
				}),
				FIELD_LABEL[question.field],
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-2 text-line-strong",
					children: "/"
				}),
				question.category
			]
		}), question.kind === "mcq" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(McqView, {
			q: question,
			value: typeof value === "number" ? value : null,
			onChange
		}) : question.kind === "multi" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MultiView, {
			q: question,
			value: isRecord(value) ? value : {},
			onChange
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EssayView, {
			q: question,
			value: isRecord(value) ? value : {},
			onChange
		})]
	});
}
function McqView({ q, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "mt-3 text-base font-medium leading-relaxed sm:text-[17px]",
		children: q.stem
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-5 grid gap-2",
		children: q.choices.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceRow, {
			label: CHOICE_KEYS[i],
			text: c,
			selected: value === i,
			onSelect: () => onChange(i)
		}, i))
	})] });
}
function MultiView({ q, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display mt-2 text-lg font-semibold",
			children: q.title
		}),
		q.passage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "mt-4 max-h-[50vh] overflow-auto whitespace-pre-wrap rounded-lg bg-paper-2 p-4 text-sm leading-relaxed text-ink-soft",
			children: q.passage
		}) : null,
		q.code ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "mt-3 overflow-auto rounded-lg bg-navy px-4 py-3 font-mono text-[13px] leading-relaxed text-navy-fg",
			children: q.code
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm leading-relaxed",
			children: q.stem
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-6",
			children: q.blanks.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-medium text-navy",
				children: [b.label, b.prompt ? `　${b.prompt}` : ""]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 grid gap-2",
				children: b.choices.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceRow, {
					label: CHOICE_KEYS[i] ?? `${i + 1}`,
					text: c,
					selected: value[b.id] === i,
					onSelect: () => onChange({
						...asMap(value),
						[b.id]: i
					})
				}, i))
			})] }, b.id))
		})
	] });
}
function EssayView({ q, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display mt-2 text-lg font-semibold",
			children: q.title
		}),
		q.required ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 inline-block rounded-full bg-navy px-2.5 py-0.5 text-xs text-navy-fg",
			children: "必須"
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "mt-4 max-h-[45vh] overflow-auto whitespace-pre-wrap rounded-lg bg-paper-2 p-4 text-sm leading-relaxed text-ink-soft",
			children: q.passage
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-6",
			children: q.parts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "border-t border-line pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-semibold text-navy",
						children: [p.label, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "ml-2 font-normal text-muted",
							children: ["配点 ", p.maxPoints]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-relaxed",
						children: p.prompt
					}),
					p.type === "choice" && p.choices ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 grid gap-2",
						children: p.choices.map((c, i) => {
							const key = CHOICE_KEYS[i] ?? String(i);
							const selected = value[p.id] === key || value[p.id] === c;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceRow, {
								label: key,
								text: c,
								selected: Boolean(selected),
								onSelect: () => onChange({
									...asMap(value),
									[p.id]: key
								})
							}, i);
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "mt-3 min-h-28 w-full rounded-lg border border-line bg-paper px-3 py-2 text-sm",
						placeholder: p.type === "calc" ? "計算過程と答え" : "解答を入力",
						value: String(value[p.id] ?? ""),
						onChange: (e) => onChange({
							...asMap(value),
							[p.id]: e.target.value
						})
					})
				]
			}, p.id))
		})
	] });
}
function ChoiceRow({ label, text, selected, onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onSelect,
		className: "flex min-h-11 w-full items-start gap-3 rounded-lg border px-3 py-2.5 text-left text-sm transition-colors duration-150 " + (selected ? "border-navy bg-paper-2 text-ink" : "border-line bg-card hover:border-line-strong hover:bg-paper-2"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-0.5 grid size-7 shrink-0 place-items-center rounded-full text-xs font-semibold " + (selected ? "bg-navy text-navy-fg" : "bg-paper-2 text-ink-soft"),
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pt-0.5 leading-relaxed",
			children: text
		})]
	}) });
}
function isRecord(v) {
	return typeof v === "object" && v !== null && !Array.isArray(v);
}
function asMap(v) {
	const out = {};
	for (const [k, val] of Object.entries(v)) if (typeof val === "number" || typeof val === "string") out[k] = val;
	else if (val == null) out[k] = null;
	else out[k] = String(val);
	return out;
}
function ExamLayout() {
	if (useRouterState({ select: (s) => s.location.pathname }).endsWith("/result")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExamRoom, {});
}
function ExamRoom() {
	const { attemptId } = Route$3.useParams();
	const nav = useNavigate();
	const [data, setData] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)(null);
	const [idx, setIdx] = (0, import_react.useState)(0);
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [flags, setFlags] = (0, import_react.useState)({});
	const [picked, setPicked] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [confirmOpen, setConfirmOpen] = (0, import_react.useState)(false);
	const submitting = (0, import_react.useRef)(false);
	const reload = (0, import_react.useCallback)(async () => {
		const res = await getAttempt({ data: { attemptId } });
		if (res.attempt.status === "completed") {
			nav({
				to: "/exam/$attemptId/result",
				params: { attemptId }
			});
			return res;
		}
		setData(res);
		const a = {};
		const f = {};
		for (const row of res.answers) {
			a[row.questionId] = row.answer;
			f[row.questionId] = row.flagged;
		}
		setAnswers(a);
		setFlags(f);
		setIdx(0);
		const req = res.phase.selectable?.requiredIds ?? [];
		setPicked(res.questions.filter((q) => q.kind === "essay" && q.required || req.some((r) => q.id.endsWith(`-${r}`) || q.id.endsWith(r))).map((q) => q.id));
		return res;
	}, [attemptId, nav]);
	(0, import_react.useEffect)(() => {
		reload().catch((e) => setErr(e instanceof Error ? e.message : "読み込めません"));
	}, [reload]);
	const questions = data?.questions ?? [];
	const q = questions[idx];
	const exam = data?.exam;
	const phase = data?.phase;
	const attempt = data?.attempt;
	const persist = (0, import_react.useMemo)(() => {
		let t;
		return (questionId, answer, flagged) => {
			window.clearTimeout(t);
			t = window.setTimeout(() => {
				saveAnswer({ data: {
					attemptId,
					questionId,
					answer,
					flagged
				} }).catch(() => void 0);
			}, 350);
		};
	}, [attemptId]);
	const answersRef = (0, import_react.useRef)(answers);
	const flagsRef = (0, import_react.useRef)(flags);
	const questionsRef = (0, import_react.useRef)(questions);
	answersRef.current = answers;
	flagsRef.current = flags;
	questionsRef.current = questions;
	function setAns(v) {
		if (!q) return;
		setAnswers((s) => ({
			...s,
			[q.id]: v
		}));
		persist(q.id, v, flags[q.id] ?? false);
	}
	function toggleFlag() {
		if (!q) return;
		const next = !flags[q.id];
		setFlags((s) => ({
			...s,
			[q.id]: next
		}));
		persist(q.id, answers[q.id] ?? null, next);
	}
	const finishPhase = (0, import_react.useCallback)(async () => {
		if (submitting.current) return;
		submitting.current = true;
		setBusy(true);
		try {
			await saveAnswers({ data: {
				attemptId,
				items: questionsRef.current.map((item) => ({
					questionId: item.id,
					answer: answersRef.current[item.id] ?? null,
					flagged: flagsRef.current[item.id] ?? false
				}))
			} });
			if ((await submitPhase({ data: { attemptId } })).done) {
				nav({
					to: "/exam/$attemptId/result",
					params: { attemptId }
				});
				return;
			}
			toast.success("科目を提出しました。次の科目に進みます。");
			await reload();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "提出に失敗しました");
		} finally {
			submitting.current = false;
			setBusy(false);
			setConfirmOpen(false);
		}
	}, [
		attemptId,
		nav,
		reload
	]);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			const tag = e.target?.tagName;
			if (tag === "TEXTAREA" || tag === "INPUT") return;
			if (e.key === "ArrowLeft") setIdx((i) => Math.max(0, i - 1));
			if (e.key === "ArrowRight") setIdx((i) => Math.min(questionsRef.current.length - 1, i + 1));
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	async function onSelectConfirm() {
		if (!phase?.selectable) return;
		setBusy(true);
		try {
			await confirmSelection({ data: {
				attemptId,
				selectedIds: picked
			} });
			await reload();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "選択を確定できません");
		} finally {
			setBusy(false);
		}
	}
	if (err) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		requireAuth: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "p-8 text-fail",
			children: err
		})
	});
	if (!data || !exam || !phase || !attempt) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		requireAuth: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-4 py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-48 animate-pulse rounded bg-line" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-6 h-64 animate-pulse rounded-xl bg-line/70" })]
		})
	});
	if (data.needsSelect && phase.selectable) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectPhase, {
		exam,
		phase,
		questions,
		picked,
		setPicked,
		busy,
		onConfirm: onSelectConfirm
	});
	const answered = questions.filter((x) => hasAnswer(answers[x.id])).length;
	const pct = questions.length ? Math.round(answered / questions.length * 100) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		requireAuth: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-line bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: exam.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-base font-semibold",
						children: phase.label
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExamTimer, {
						startedAt: attempt.phaseStartedAt,
						durationMin: phase.durationMin,
						onExpire: () => void finishPhase()
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1 bg-paper-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-1 bg-navy transition-[width] duration-200",
						style: { width: `${pct}%` }
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-4 px-4 py-4 lg:grid-cols-[minmax(0,1fr)_220px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [q ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionView, {
					question: q,
					index: idx,
					total: questions.length,
					value: answers[q.id] ?? null,
					onChange: setAns
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 rounded-lg border border-line bg-card px-4 text-sm disabled:opacity-40",
							disabled: idx <= 0,
							onClick: () => setIdx((i) => i - 1),
							children: "前へ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 rounded-lg border border-line bg-card px-4 text-sm disabled:opacity-40",
							disabled: idx >= questions.length - 1,
							onClick: () => setIdx((i) => i + 1),
							children: "次へ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: toggleFlag,
							className: "inline-flex h-11 items-center gap-1.5 rounded-lg border border-line bg-card px-3 text-sm",
							children: [flags[q?.id ?? ""] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { className: "size-4 text-flag" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlagOff, { className: "size-4 text-muted" }), "見直し"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "ml-auto text-sm text-muted",
							children: [
								"解答 ",
								answered,
								"/",
								questions.length
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 rounded-lg bg-navy px-4 text-sm font-medium text-navy-fg",
							onClick: () => setConfirmOpen(true),
							children: "この科目を提出"
						})
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "no-print rounded-xl border border-line bg-card p-3 lg:sticky lg:top-20 lg:h-fit",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-1 text-xs font-medium text-muted",
						children: "問題一覧"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 grid grid-cols-8 gap-1.5 lg:grid-cols-5",
						children: questions.map((item, i) => {
							const state = flags[item.id] ? "flag" : hasAnswer(answers[item.id]) ? "done" : "empty";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setIdx(i),
								className: "grid h-9 place-items-center rounded-md text-xs font-medium " + (i === idx ? "ring-2 ring-navy ring-offset-1 ring-offset-card " : "") + (state === "flag" ? "bg-warn-bg text-warn" : state === "done" ? "bg-navy text-navy-fg" : "bg-paper-2 text-muted"),
								children: i + 1
							}, item.id);
						})
					})]
				})]
			}),
			confirmOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 grid place-items-center bg-ink/40 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-2xl bg-card p-6 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg font-semibold",
							children: "科目を提出しますか？"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-ink-soft",
							children: [
								"未解答 ",
								questions.length - answered,
								" 問。提出後はこの科目に戻れません。"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-11 rounded-lg border border-line px-4 text-sm",
								onClick: () => setConfirmOpen(false),
								children: "戻る"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy,
								className: "h-11 rounded-lg bg-navy px-4 text-sm text-navy-fg",
								onClick: () => void finishPhase(),
								children: busy ? "採点中…" : "提出する"
							})]
						})
					]
				})
			}) : null
		]
	});
}
function SelectPhase({ exam, phase, questions, picked, setPicked, busy, onConfirm }) {
	const required = phase.selectable?.requiredIds ?? [];
	function toggle(id) {
		if (required.some((r) => id.endsWith(`-${r}`) || id.endsWith(r))) return;
		if (picked.includes(id)) setPicked(picked.filter((x) => x !== id));
		else if (picked.length >= pick) return;
		else setPicked([...picked, id]);
	}
	const pick = phase.selectable?.pick ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		requireAuth: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-4 py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-navy",
					children: exam.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "font-display mt-1 text-2xl font-semibold",
					children: [phase.label, " — 問題選択"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-ink-soft",
					children: [
						phase.selectable?.total,
						"問から",
						pick,
						"問を選んでください。必須問題は外せません。"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-6 grid gap-2",
					children: questions.map((q, i) => {
						const title = q.kind === "mcq" ? q.stem.slice(0, 40) : q.title;
						const isReq = q.kind === "essay" && (q.required || required.some((r) => q.id.endsWith(`-${r}`)));
						const on = picked.includes(q.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => toggle(q.id),
							className: "flex w-full items-start gap-3 rounded-xl border px-4 py-3 text-left " + (on ? "border-navy bg-paper-2" : "border-line bg-card"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 grid size-7 place-items-center rounded-full bg-navy text-xs text-navy-fg",
								children: i + 1
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-sm font-medium",
								children: [q.category, isReq ? "（必須）" : ""]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 block text-sm text-ink-soft",
								children: title
							})] })]
						}) }, q.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"選択 ",
							picked.length,
							"/",
							pick
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy || picked.length !== pick,
						onClick: onConfirm,
						className: "h-11 rounded-lg bg-navy px-5 text-sm text-navy-fg disabled:opacity-50",
						children: busy ? "確定中…" : "選択を確定して解答開始"
					})]
				})
			]
		})
	});
}
function hasAnswer(v) {
	if (v == null) return false;
	if (typeof v === "number") return true;
	if (typeof v === "string") return v.trim().length > 0;
	return Object.values(v).some((x) => x != null && String(x).length > 0);
}
//#endregion
export { ExamLayout as component };
