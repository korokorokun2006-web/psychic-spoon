import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as EXAM_ORDER, t as EXAMS } from "./catalog-d6Irk40O.mjs";
import { d as ArrowRight, l as Clock3, o as GraduationCap } from "../_libs/lucide-react.mjs";
import { n as useCurrentUserState } from "./use-current-user-ClOiUQ-z.mjs";
import { a as listAttempts, t as AppShell } from "./exam-api-Cgv7AjeX.mjs";
import { r as FIELD_LABEL } from "./labels-TS9A5-VG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-AYq_XLo2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const { user, isPending } = useCurrentUserState();
	const [resume, setResume] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		listAttempts().then((rows) => {
			const open = rows.find((r) => r.status === "in_progress");
			if (open) setResume({
				id: open.id,
				name: EXAMS[open.examKind].name,
				phase: EXAMS[open.examKind].phases.find((p) => p.key === open.currentPhase)?.label ?? open.currentPhase
			});
		}).catch(() => void 0);
	}, [user]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-6xl px-4 pb-10 pt-10 sm:pt-14",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-[0.22em] text-navy",
						children: "IPA 情報処理技術者試験"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-3 max-w-2xl text-3xl font-semibold leading-tight text-balance sm:text-5xl",
						children: "CBT模擬試験センター"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-sm leading-relaxed text-pretty text-ink-soft sm:text-base",
						children: "ITパスポート・基本情報・応用情報・データベーススペシャリストを、制限時間・連続受験・1,000点換算まで本番の規程に沿って実施します。解答・模範解答・解説は全問、結果画面とPDFに残ります。"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/history",
							className: "inline-flex h-11 items-center gap-2 rounded-full border border-line bg-card px-4 text-sm font-medium",
							children: "学習履歴を見る"
						}), !isPending && !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/login",
							className: "inline-flex h-11 items-center gap-2 rounded-full bg-navy px-4 text-sm font-medium text-navy-fg",
							children: ["ログインしてはじめる", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
						}) : null]
					}),
					resume ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/exam/$attemptId",
						params: { attemptId: resume.id },
						className: "mt-6 flex max-w-xl items-center justify-between rounded-xl border border-navy bg-card px-4 py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"続きから：",
							resume.name,
							"（",
							resume.phase,
							"）"
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-navy" })]
					}) : null
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto grid max-w-6xl gap-4 px-4 pb-16 sm:grid-cols-2",
			children: EXAM_ORDER.map((k) => {
				const e = EXAMS[k];
				const mins = e.phases.reduce((s, p) => s + p.durationMin, 0);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/exams/$kind",
					params: { kind: k },
					className: "group rounded-2xl border border-line bg-card p-5 shadow-card transition-transform duration-200 hover:-translate-y-0.5 sm:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-navy px-2.5 py-1 text-xs font-semibold text-navy-fg",
								children: e.short
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-5 text-muted" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display mt-4 text-xl font-semibold",
							children: e.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 line-clamp-3 text-sm leading-relaxed text-ink-soft",
							children: e.blurb
						}),
						e.fieldMix ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs text-muted",
							children: Object.entries(e.fieldMix).map(([f, n]) => `${FIELD_LABEL[f]} ${n}問`).join(" · ")
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 grid gap-1.5 text-sm text-ink-soft",
							children: e.phases.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums text-muted",
									children: [
										p.selectable ? `${p.selectable.total}問中${p.selectable.pick}問` : `${p.questionCount}問`,
										" / ",
										p.durationMin,
										"分"
									]
								})]
							}, p.key))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex items-center justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1.5 text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-4" }),
									"合計 ",
									mins,
									" 分"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 font-medium text-navy",
								children: ["実施回を選ぶ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 transition-transform duration-150 group-hover:translate-x-0.5" })]
							})]
						})
					]
				}, k);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-line bg-card",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, {
						t: "本番に近い進行",
						d: "科目は連続受験。応用情報・高度試験は長文の選択解答にも対応します。"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, {
						t: "1,000点換算",
						d: "採点対象問をランダムに定め、各科目600点以上が合格。全科目合格で総合合格です。"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, {
						t: "解説とPDF",
						d: "全問のあなたの解答・模範解答・解説を一覧し、印刷してPDFに残せます。"
					})
				]
			})
		})
	] });
}
function Note({ t, d }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "font-display text-base font-semibold",
		children: t
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-sm leading-relaxed text-ink-soft",
		children: d
	})] });
}
//#endregion
export { Home as component };
