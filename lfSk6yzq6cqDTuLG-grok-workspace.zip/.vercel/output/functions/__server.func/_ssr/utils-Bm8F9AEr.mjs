import { c as __exportAll } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-Bm8F9AEr.js
var utils_exports = /* @__PURE__ */ __exportAll({
	formatDuration: () => formatDuration,
	formatRaw: () => formatRaw,
	formatScore: () => formatScore,
	hashString: () => hashString,
	pickN: () => pickN,
	seededRandom: () => seededRandom,
	shuffle: () => shuffle
});
function seededRandom(seed) {
	let s = seed >>> 0;
	return () => {
		s = 1664525 * s + 1013904223 >>> 0;
		return s / 4294967296;
	};
}
function hashString(input) {
	let h = 2166136261;
	for (let i = 0; i < input.length; i += 1) {
		h ^= input.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
function shuffle(items, rand) {
	const copy = [...items];
	for (let i = copy.length - 1; i > 0; i -= 1) {
		const j = Math.floor(rand() * (i + 1));
		const tmp = copy[i];
		copy[i] = copy[j];
		copy[j] = tmp;
	}
	return copy;
}
function pickN(items, n, rand) {
	return shuffle(items, rand).slice(0, Math.min(n, items.length));
}
function formatDuration(totalSec) {
	const sec = Math.max(0, Math.floor(totalSec));
	const h = Math.floor(sec / 3600);
	const m = Math.floor(sec % 3600 / 60);
	const s = sec % 60;
	if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
	return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function formatRaw(correct, total) {
	const fmt = (n) => Math.abs(n - Math.round(n)) < .05 ? String(Math.round(n)) : n.toFixed(1);
	return `${fmt(correct)}/${fmt(total)}`;
}
function formatScore(n) {
	if (n == null || Number.isNaN(n)) return "—";
	return Math.round(n).toLocaleString("ja-JP");
}
//#endregion
export { pickN as a, utils_exports as c, hashString as i, formatRaw as n, seededRandom as o, formatScore as r, shuffle as s, formatDuration as t };
