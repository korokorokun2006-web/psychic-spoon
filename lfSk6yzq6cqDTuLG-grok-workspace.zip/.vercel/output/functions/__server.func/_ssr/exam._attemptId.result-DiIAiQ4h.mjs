import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as YEAR_LABEL } from "./catalog-d6Irk40O.mjs";
import { n as formatRaw, r as formatScore } from "./utils-Bm8F9AEr.mjs";
import { r as Printer } from "../_libs/lucide-react.mjs";
import { n as Route } from "./router-DlJC4z8l.mjs";
import { i as getResult, t as AppShell } from "./exam-api-Cgv7AjeX.mjs";
import { n as EXAM_PASS_LABEL, r as FIELD_LABEL, t as EXAM_FAIL_LABEL } from "./labels-TS9A5-VG.mjs";
import { t as CHOICE_KEYS } from "./types-DS8IYQ4-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exam._attemptId.result-DiIAiQ4h.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ResultPage() {
	const { attemptId } = Route.useParams();
	const [err, setErr] = (0, import_react.useState)(null);
	const [data, setData] = (0, import_react.useState)(null);
	const [filter, setFilter] = (0, import_react.useState)("all");
	(0, import_react.useEffect)(() => {
		getResult({ data: { attemptId } }).then(setData).catch((e) => setErr(e instanceof Error ? e.message : "結果を取得できません"));
	}, [attemptId]);
	const visible = (0, import_react.useMemo)(() => {
		if (!data) return [];
		const byId = new Map(data.answers.map((a) => [a.questionId, a]));
		return data.questions.filter((q) => {
			const row = byId.get(q.id);
			if (filter === "all") return true;
			if (filter === "wrong") return row?.isCorrect === false;
			return !hasAnswer(row?.answer);
		});
	}, [data, filter]);
	if (err) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		requireAuth: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "p-8 text-fail",
			children: err
		})
	});
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		requireAuth: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-3xl px-4 py-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 animate-pulse rounded-xl bg-line" })
		})
	});
	const { attempt, exam, questions, answers } = data;
	const byId = new Map(answers.map((a) => [a.questionId, a]));
	const overall = attempt.passed ? EXAM_PASS_LABEL[exam.kind] : EXAM_FAIL_LABEL[exam.kind];
	const session = YEAR_LABEL[attempt.sessionKey] ?? (attempt.sessionKey === "random" ? "ランダム" : attempt.sessionKey);
	const wrongN = answers.filter((a) => a.isCorrect === false).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		requireAuth: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-4 py-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "no-print mb-4 flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/history",
						className: "text-sm text-muted",
						children: "学習履歴へ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => window.print(),
						className: "inline-flex h-11 items-center gap-2 rounded-lg bg-navy px-4 text-sm font-medium text-navy-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "PDFで出力"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "rounded-2xl border border-line bg-card p-6 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-[0.2em] text-navy",
							children: "SCORE REPORT"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display mt-2 text-2xl font-semibold text-balance sm:text-3xl",
							children: overall
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								exam.name,
								"／",
								session
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 grid gap-2 sm:grid-cols-2",
							children: attempt.scores.map((s) => {
								const ph = exam.phases.find((p) => p.key === s.phase);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl px-4 py-3 " + (s.passed ? "bg-pass-bg text-pass" : "bg-fail-bg text-fail"),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs",
											children: ph?.label ?? s.phase
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "font-display text-2xl font-semibold tabular-nums",
											children: [formatScore(s.scaled), " / 1,000"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs",
											children: [s.passed ? "科目合格（600点以上）" : "科目不合格（600点未満）", s.rawTotal > 0 ? ` · 得点 ${formatRaw(s.rawCorrect, s.rawTotal)}` : ""]
										})
									]
								}, s.phase);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs leading-relaxed text-muted",
							children: "採点対象問は開始時に無作為に決まり、1問を等しく1,000点満点へ換算しています。記述は要点の一致で自動採点し、AIが使えるときは講評も付けます。採点対象外の問題も、解答と解説はすべて残します。"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 flex flex-wrap items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-semibold",
						children: "全問の解答と解説"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							"あなたの解答・模範解答・解説を全",
							questions.length,
							"問掲載しています。"
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "no-print flex rounded-full bg-paper-2 p-1 text-xs",
						children: [
							["all", `すべて ${questions.length}`],
							["wrong", `不正解 ${wrongN}`],
							["unanswered", "未解答"]
						].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setFilter(k),
							className: "rounded-full px-3 py-1.5 " + (filter === k ? "bg-card font-medium shadow-sm" : "text-muted"),
							children: label
						}, k))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid gap-10",
					children: [exam.phases.map((ph) => {
						const ids = attempt.papers[ph.key] ?? [];
						const phaseQuestions = ids.map((id) => questions.find((q) => q.id === id)).filter((q) => Boolean(q)).filter((q) => {
							const row = byId.get(q.id);
							if (filter === "all") return true;
							if (filter === "wrong") return row?.isCorrect === false;
							return !hasAnswer(row?.answer);
						});
						if (phaseQuestions.length === 0) return null;
						const score = attempt.scores.find((s) => s.phase === ph.key);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "font-display text-lg font-semibold",
							children: [ph.label, score ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-2 text-sm font-sans font-medium text-muted",
								children: [
									formatScore(score.scaled),
									"点 / ",
									score.passed ? "科目合格" : "科目不合格"
								]
							}) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 grid gap-6",
							children: phaseQuestions.map((q) => {
								const i = ids.indexOf(q.id);
								const chosen = ph.selectable ? attempt.selectedIds.includes(q.id) : true;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewCard, {
									q,
									i,
									row: byId.get(q.id),
									scored: attempt.scoredIds.includes(q.id),
									chosen
								}, q.id);
							})
						})] }, ph.key);
					}), visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "該当する問題はありません。"
					}) : null]
				})
			]
		})
	});
}
function ReviewCard({ q, i, row, scored, chosen }) {
	const ok = row?.isCorrect;
	const partial = row?.earned != null && row.maxPoints != null && row.earned > 0 && row.earned < row.maxPoints;
	const label = !chosen ? "未選択" : ok ? "正解" : ok === false ? partial ? "部分点" : "不正解" : "未解答";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "break-inside-avoid rounded-xl border border-line bg-card p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2 text-xs",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-medium",
					children: ["問", i + 1]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: FIELD_LABEL[q.field]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: q.category
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "rounded-full px-2 py-0.5 " + (!chosen ? "bg-paper-2 text-muted" : ok ? "bg-pass-bg text-pass" : ok === false ? "bg-fail-bg text-fail" : "bg-paper-2 text-muted"),
					children: [label, chosen && row?.earned != null && row.maxPoints != null ? ` ${row.earned}/${row.maxPoints}` : ""]
				}),
				chosen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full px-2 py-0.5 " + (scored ? "bg-navy text-navy-fg" : "bg-paper-2 text-muted"),
					children: scored ? "採点対象" : "採点対象外"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-paper-2 px-2 py-0.5 text-muted",
					children: "採点対象外"
				})
			]
		}), q.kind === "mcq" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 whitespace-pre-wrap text-sm leading-relaxed",
				children: q.stem
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 text-sm",
				children: q.choices.map((c, ci) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: ci === q.answer ? "font-medium text-pass" : "",
					children: [
						CHOICE_KEYS[ci],
						" ",
						c
					]
				}, ci))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: "あなたの解答："
				}), formatMcq(row?.answer, q.choices)]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: "模範解答："
					}),
					CHOICE_KEYS[q.answer],
					" ",
					q.choices[q.answer]
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-pretty text-ink-soft",
				children: q.explanation
			})
		] }) : q.kind === "multi" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-2 font-medium",
				children: q.title
			}),
			q.passage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-2 max-h-48 overflow-auto whitespace-pre-wrap rounded bg-paper-2 p-3 text-xs",
				children: q.passage
			}) : null,
			q.code ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-2 overflow-auto rounded bg-navy p-3 font-mono text-xs text-navy-fg",
				children: q.code
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm",
				children: q.stem
			}),
			q.blanks.map((b) => {
				const ua = isRecord(row?.answer) ? row?.answer[b.id] : null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: b.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["あなたの解答：", formatChoiceIndex(ua, b.choices)] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"模範解答：",
							CHOICE_KEYS[b.answer] ?? b.answer,
							" ",
							b.choices[b.answer]
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-ink-soft",
							children: b.explanation
						})
					]
				}, b.id);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-ink-soft",
				children: q.explanation
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-2 font-medium",
				children: q.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-2 max-h-56 overflow-auto whitespace-pre-wrap rounded bg-paper-2 p-3 text-xs",
				children: q.passage
			}),
			q.parts.map((p) => {
				const ua = isRecord(row?.answer) ? row?.answer[p.id] : "";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 border-t border-line pt-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-medium",
							children: [
								p.label,
								"（",
								p.maxPoints,
								"点）"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1",
							children: p.prompt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 whitespace-pre-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "あなたの解答："
							}), String(ua || "（未解答）")]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 whitespace-pre-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "模範解答："
							}), p.answer]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 leading-relaxed text-ink-soft",
							children: p.explanation
						})
					]
				}, p.id);
			}),
			row?.aiFeedback ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 rounded-md bg-paper-2 p-3 text-sm text-ink-soft",
				children: ["AI講評：", row.aiFeedback]
			}) : null
		] })]
	});
}
function formatMcq(v, choices) {
	if (typeof v !== "number" || v < 0 || v > 3) return "（未解答）";
	return `${CHOICE_KEYS[v]} ${choices[v]}`;
}
function formatChoiceIndex(v, choices) {
	if (typeof v !== "number" || !choices[v]) return "（未解答）";
	return `${CHOICE_KEYS[v] ?? v} ${choices[v]}`;
}
function isRecord(v) {
	return typeof v === "object" && v !== null && !Array.isArray(v);
}
function hasAnswer(v) {
	if (v == null) return false;
	if (typeof v === "number") return true;
	if (typeof v === "string") return v.trim().length > 0;
	return Object.values(v).some((x) => x != null && String(x).length > 0);
}
//#endregion
export { ResultPage as component };
