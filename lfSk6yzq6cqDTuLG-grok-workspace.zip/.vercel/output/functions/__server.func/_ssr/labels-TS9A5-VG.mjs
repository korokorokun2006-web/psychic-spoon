//#region node_modules/.nitro/vite/services/ssr/assets/labels-TS9A5-VG.js
var FIELD_LABEL = {
	strategy: "ストラテジ系",
	management: "マネジメント系",
	technology: "テクノロジ系",
	advanced: "高度専門"
};
var EXAM_PASS_LABEL = {
	ip: "ＩＴパスポート試験　合格",
	fe: "基本情報技術者試験　合格",
	ap: "応用情報技術者試験　合格",
	db: "データベーススペシャリスト試験　合格"
};
var EXAM_FAIL_LABEL = {
	ip: "ＩＴパスポート試験　不合格",
	fe: "基本情報技術者試験　不合格",
	ap: "応用情報技術者試験　不合格",
	db: "データベーススペシャリスト試験　不合格"
};
//#endregion
export { EXAM_PASS_LABEL as n, FIELD_LABEL as r, EXAM_FAIL_LABEL as t };
