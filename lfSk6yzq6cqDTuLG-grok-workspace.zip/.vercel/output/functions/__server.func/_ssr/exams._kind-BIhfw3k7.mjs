import { o as __toESM } from "../_runtime.mjs";
import { C as useNavigate, Q as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as getExam } from "./catalog-d6Irk40O.mjs";
import { f as ArrowLeft, l as Clock3 } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as Route$2 } from "./router-DlJC4z8l.mjs";
import { n as useCurrentUserState } from "./use-current-user-ClOiUQ-z.mjs";
import { c as startAttempt, t as AppShell } from "./exam-api-Cgv7AjeX.mjs";
import { r as FIELD_LABEL } from "./labels-TS9A5-VG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exams._kind-BIhfw3k7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ExamSelect() {
	const { kind } = Route$2.useParams();
	const exam = getExam(kind);
	const nav = useNavigate();
	const { user, isPending } = useCurrentUserState();
	const [busy, setBusy] = (0, import_react.useState)(null);
	if (!exam) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "p-8",
		children: "試験が見つかりません。"
	}) });
	const current = exam;
	async function start(sessionKey) {
		if (!user) {
			nav({ to: "/login" });
			return;
		}
		setBusy(sessionKey);
		try {
			const res = await startAttempt({ data: {
				kind: current.kind,
				sessionKey
			} });
			nav({
				to: "/exam/$attemptId",
				params: { attemptId: res.attempt.id }
			});
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "開始できませんでした");
			setBusy(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "inline-flex items-center gap-1 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "試験一覧"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-xs font-semibold tracking-[0.2em] text-navy",
				children: exam.short
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display mt-2 text-3xl font-semibold",
				children: exam.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-ink-soft",
				children: exam.blurb
			}),
			exam.fieldMix ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-muted",
				children: ["出題分野：", Object.entries(exam.fieldMix).map(([f, n]) => `${FIELD_LABEL[f]} ${n}問`).join("、")]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-xl border border-line bg-card p-4 text-sm",
				children: [exam.phases.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 border-b border-line py-2 last:border-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: p.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums text-muted",
						children: [
							p.selectable ? `${p.selectable.total}問中${p.selectable.pick}問選択` : `${p.questionCount}問`,
							"／",
							p.durationMin,
							"分／",
							p.scoredCount,
							"問採点／",
							p.maxScore,
							"点"
						]
					})]
				}, p.key)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 flex items-center gap-1.5 text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-4" }),
						"合格基準：各科目 600点以上（",
						exam.phases.length > 1 ? "全科目" : "600点以上で",
						"合格）"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-10 text-sm font-semibold text-ink-soft",
				children: "実施回を選ぶ"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid gap-2",
				children: exam.sessions.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: busy !== null || isPending,
					onClick: () => start(s.key),
					className: "flex min-h-14 w-full items-center justify-between rounded-xl border border-line bg-card px-4 text-left transition-colors duration-150 hover:border-navy disabled:opacity-60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: s.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-navy",
						children: busy === s.key ? "準備中…" : user ? "受験を開始" : "ログインして開始"
					})]
				}) }, s.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-xs leading-relaxed text-muted",
				children: "問題は学習用のオリジナルです。採点対象問は開始時に無作為に決まり、受験中はどれが採点対象か分かりません。制限時間終了で自動提出されます。"
			})
		]
	}) });
}
//#endregion
export { ExamSelect as component };
