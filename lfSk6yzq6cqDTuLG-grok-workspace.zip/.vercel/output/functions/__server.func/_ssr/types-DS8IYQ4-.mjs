//#region node_modules/.nitro/vite/services/ssr/assets/types-DS8IYQ4-.js
var CHOICE_KEYS = [
	"ア",
	"イ",
	"ウ",
	"エ"
];
//#endregion
export { CHOICE_KEYS as t };
