import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as EXAM_ORDER, r as YEAR_LABEL, t as EXAMS } from "./catalog-d6Irk40O.mjs";
import { r as formatScore } from "./utils-Bm8F9AEr.mjs";
import { a as listAttempts, t as AppShell } from "./exam-api-Cgv7AjeX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/history-DVIc5LxX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HistoryPage() {
	const [rows, setRows] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)(null);
	const [kind, setKind] = (0, import_react.useState)("all");
	(0, import_react.useEffect)(() => {
		listAttempts().then((r) => setRows(r)).catch((e) => setErr(e instanceof Error ? e.message : "履歴を取得できません"));
	}, []);
	const shown = rows?.filter((r) => kind === "all" || r.examKind === kind) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		requireAuth: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-4 py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold",
					children: "学習履歴"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-ink-soft",
					children: "受験の点数と合否を一覧できます。完了した試験は解答・解説を開けます。"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						on: kind === "all",
						onClick: () => setKind("all"),
						children: "すべて"
					}), EXAM_ORDER.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						on: kind === k,
						onClick: () => setKind(k),
						children: EXAMS[k].short
					}, k))]
				}),
				err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-fail",
					children: err
				}) : null,
				rows === null && !err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-8 h-40 animate-pulse rounded-xl bg-line" }) : null,
				shown && shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 rounded-2xl border border-dashed border-line-strong px-6 py-16 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: "まだ受験記録がありません"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "mt-3 inline-block text-sm text-navy",
						children: "試験を選ぶ"
					})]
				}) : null,
				shown && shown.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 overflow-x-auto rounded-xl border border-line bg-card",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[640px] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-b border-line bg-paper-2 text-xs text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 font-medium",
									children: "日時"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 font-medium",
									children: "試験"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 font-medium",
									children: "実施回"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 font-medium",
									children: "得点"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 font-medium",
									children: "判定"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-4 py-3 font-medium" })
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: shown.map((r) => {
							const exam = EXAMS[r.examKind];
							const session = YEAR_LABEL[r.sessionKey] ?? (r.sessionKey === "random" ? "ランダム" : r.sessionKey);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-line last:border-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 tabular-nums text-muted",
										children: new Date(r.startedAt).toLocaleString("ja-JP")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-medium",
										children: exam.short
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: session
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 tabular-nums",
										children: r.scores.length ? r.scores.map((s) => {
											return `${exam.phases.find((p) => p.key === s.phase)?.label ?? s.phase} ${formatScore(s.scaled)}`;
										}).join(" / ") : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: r.status !== "completed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-warn",
											children: "実施中"
										}) : r.passed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-pass",
											children: "合格"
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-fail",
											children: "不合格"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-right",
										children: r.status === "completed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/exam/$attemptId/result",
											params: { attemptId: r.id },
											className: "text-navy",
											children: "解説"
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/exam/$attemptId",
											params: { attemptId: r.id },
											className: "text-navy",
											children: "続ける"
										})
									})
								]
							}, r.id);
						}) })]
					})
				}) : null
			]
		})
	});
}
function Chip({ on, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: "h-9 rounded-full px-3 text-sm " + (on ? "bg-navy text-navy-fg" : "border border-line bg-card text-ink-soft"),
		children
	});
}
//#endregion
export { HistoryPage as component };
