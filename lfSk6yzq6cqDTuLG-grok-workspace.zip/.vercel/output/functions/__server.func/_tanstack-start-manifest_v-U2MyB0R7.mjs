//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-U2MyB0R7.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/history",
			"/login",
			"/exam/$attemptId",
			"/exams/$kind",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-Biel07-b.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/preload-helper-iK0lVs3a.js",
			"/assets/link-CGabrAVI.js",
			"/assets/lazyRouteComponent-D4TnIdqg.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Biel07-b.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DLXx5s7m.js",
			"/assets/exam-api-5pq_9Yx0.js",
			"/assets/clock-3-BlUu-uMV.js",
			"/assets/use-current-user-CzUq4unU.js",
			"/assets/catalog-cj-2bEGW.js",
			"/assets/labels-DIeK6x_9.js"
		]
	},
	"/history": {
		filePath: "/workspace/src/routes/history.tsx",
		children: void 0,
		preloads: [
			"/assets/history-3PuCc9FE.js",
			"/assets/exam-api-5pq_9Yx0.js",
			"/assets/catalog-cj-2bEGW.js",
			"/assets/utils-DLao611D.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-CLc7qXGz.js",
			"/assets/client-DRhaju3Z.js",
			"/assets/use-current-user-CzUq4unU.js"
		]
	},
	"/exam/$attemptId": {
		filePath: "/workspace/src/routes/exam.$attemptId.tsx",
		children: ["/exam/$attemptId/result"],
		preloads: [
			"/assets/exam._attemptId-CtBN67N9.js",
			"/assets/exam-api-5pq_9Yx0.js",
			"/assets/labels-DIeK6x_9.js",
			"/assets/types-BXOY_QZx.js",
			"/assets/utils-DLao611D.js"
		]
	},
	"/exams/$kind": {
		filePath: "/workspace/src/routes/exams.$kind.tsx",
		children: void 0,
		preloads: [
			"/assets/exams._kind-Bmc-2ur-.js",
			"/assets/exam-api-5pq_9Yx0.js",
			"/assets/clock-3-BlUu-uMV.js",
			"/assets/use-current-user-CzUq4unU.js",
			"/assets/catalog-cj-2bEGW.js",
			"/assets/labels-DIeK6x_9.js"
		]
	},
	"/exam/$attemptId/result": {
		filePath: "/workspace/src/routes/exam.$attemptId.result.tsx",
		children: void 0,
		preloads: ["/assets/exam._attemptId.result-xC2A6p62.js", "/assets/catalog-cj-2bEGW.js"]
	}
} });
//#endregion
export { tsrStartManifest };
